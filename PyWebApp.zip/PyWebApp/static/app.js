// --- GLOBAL STATE -----------------------------------------------------------
window.state = {};            // name -> { name, value, prop }
window.onSseUpdate = null;    // optional view hook

const content = document.getElementById("content");

// --- VIEW LOADER ------------------------------------------------------------
async function loadView(name) {
  // reset hook so previous view stops receiving events
  window.onSseUpdate = null;

  const res = await fetch(`/static/views/${name}.html`, { cache: "no-cache" });
  if (!res.ok) {
    content.innerHTML = `
      <div style="padding:16px">
        <h2>View konnte nicht geladen werden</h2>
        <p><code>${name}.html</code> HTTP ${res.status}</p>
        <button onclick="loadView('menu')">⬅️ Zurück zum Menü</button>
      </div>`;
    return;
  }

  const html = await res.text();
  content.innerHTML = html;

  // execute embedded scripts (inline & external, safe)
  content.querySelectorAll("script").forEach(oldScript => {
    const s = document.createElement("script");
    [...oldScript.attributes].forEach(a => s.setAttribute(a.name, a.value));

    if (oldScript.src) {
      // avoid duplicates
      const already = [...document.scripts].some(scr => scr.src === oldScript.src);
      if (already) return;
      s.src = oldScript.src;
      s.async = false;
      s.onload = () => s.remove();
      s.onerror = () => console.error("Script load error:", s.src);
      document.body.appendChild(s);
    } else {
      s.textContent = oldScript.textContent;
      document.body.appendChild(s);
      s.remove();
    }
  });

  // re-apply the last known state to the freshly inserted DOM
  reapplyState();
}

// --- SSE --------------------------------------------------------------------
function startSSE() {
  const url = window.__STREAM_URL__ || "/stream";
  const es = new EventSource(url);

  es.onopen  = () => updateElement("status", "verbunden");
  es.onerror = () => updateElement("status", "getrennt – versuche erneut…");

  es.onmessage = (e) => {
    try {
      const msg = JSON.parse(e.data);          // {name, value, prop?, mode?}
      window.state[msg.name] = msg;            // 1) persist globally
      applyUpdate(msg);                        // 2) apply to current DOM

      if (typeof window.onSseUpdate === "function") {
        window.onSseUpdate(msg);               // 3) optional view-specific hook
      }
    } catch (err) {
      console.error("SSE error:", err);
    }
  };
}

// --- APPLY HELPERS ----------------------------------------------------------
function applyUpdate(msg) {
  // a) direct by id
  const el = document.getElementById(msg.name);
  if (el) {
    setProp(el, msg.prop || "text", msg.value);
    return;
  }

  // b) generic binding via data-bind, e.g. data-bind="lock_button:disabled, value:text"
  const bindTargets = content.querySelectorAll("[data-bind]");
  for (const node of bindTargets) {
    const bindings = String(node.getAttribute("data-bind"))
      .split(",")
      .map(s => s.trim())
      .filter(Boolean);

    for (const b of bindings) {
      const [name, prop = "text"] = b.split(":").map(x => x.trim());
      if (name === msg.name) {
        setProp(node, prop, msg.value);
      }
    }
  }
}

function setProp(el, prop, value) {
  try {
    switch (prop) {
      case "text":     el.textContent = value; break;
      case "html":     el.innerHTML = value;   break;
      case "value":    el.value = value;       break;
      case "src":      el.src = value;         break;
      case "href":     el.href = value; el.textContent = value; break;
      case "checked":  el.checked = !!value;   break;
      case "disabled": el.disabled = !!value;  break;
      default:         el.setAttribute(prop, value);
    }
  } catch (e) {
    console.warn("setProp failed", { el, prop, value, e });
  }
}

function reapplyState() {
  for (const msg of Object.values(window.state)) {
    applyUpdate(msg);
  }
}

function updateElement(id, text) {
  const el = document.getElementById(id);
  if (el) el.textContent = text;
}

// --- BOOT -------------------------------------------------------------------
document.addEventListener("DOMContentLoaded", () => {
  const startView = document.body.dataset.start || "menu";
  loadView(startView);
  startSSE();
});

window.loadView = loadView;
