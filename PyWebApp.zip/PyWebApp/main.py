import subprocess
import sys
import webview
from ui_bridge import run_server, add_worker
from producers import number_producer, text_producer
from pages import Index


# Automatically install required packages if missing
def install_requirements(install = True):
    """
    :param install:
        False -> only check if they are available (default)
        else  -> install missing packages
    """
    if install is False:
        return

    required = ["flask", "waitress", "pywebview"]  # add more packages here if needed
    for package in required:
        try:
            __import__(package)  # try importing the package
        except ImportError:
            print(f"[INFO] Installing {package}...")
            subprocess.check_call([sys.executable, "-m", "pip", "install", package])


if __name__ == "__main__":
    # Make sure all requirements are installed before running
    install_requirements(False)

    # Start background workers:
    # - choose whether to run with Flask or Waitress server
    add_worker(lambda: run_server(server="flask"))
    add_worker(number_producer)
    add_worker(text_producer)

    # Launch main UI page
    Index()

    # Start the pywebview event loop (GUI)
    webview.start()
