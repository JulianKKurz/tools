import time, random
from ui_bridge import html_refresh_variable

def number_producer():
    buf = []
    maxlen = 100
    counter = 0
    while True:
        y = random.randint(1, 100)
        buf.append(y)
        if len(buf) > maxlen:
            buf = buf[-maxlen:]
        labels = list(range(counter - len(buf) + 1, counter + 1))
        counter += 1
        html_refresh_variable({"labels": labels, "values": buf}, "chart_series", mode="replace")
        time.sleep(0.01)

def text_producer():
    texts = ["Hallo Welt!", "Ich komme aus Python 🐍", "Refresh läuft...", "Random Text!"]
    while True:
        html_refresh_variable(random.choice(texts), "randomtext")
        time.sleep(2)
