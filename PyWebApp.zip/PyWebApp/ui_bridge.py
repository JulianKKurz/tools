import secrets, json, threading, webview
from queue import Queue
import threading
from flask import Flask, Response, render_template, request, abort
from waitress import serve as waitress_serve

app = Flask(__name__)
TOKEN = secrets.token_urlsafe(16)
windows = {}

subscribers = set()
subs_lock = threading.Lock()

# ---------------------------------------------------------------------
# Hilfsfunktionen
# ---------------------------------------------------------------------
def html_init(page="index"):
    return f"http://127.0.0.1:5000/{page}?t={TOKEN}"

def html_refresh_variable(value, name, prop=None, mode="set"):
    try:
        json.dumps(value)
        val = value
    except TypeError:
        val = str(value)

    item = {"name": name, "value": val, "prop": prop, "mode": mode}
    with subs_lock:
        dead = []
        for q in list(subscribers):
            try:
                q.put(item, block=False)
            except Exception:
                dead.append(q)
        for q in dead:
            subscribers.discard(q)

def create_page(title=None, page_id="index", js_api=None, **kwargs):
    url = html_init(page_id)
    win = webview.create_window(title or page_id.capitalize(), url, js_api=js_api, **kwargs)
    windows[page_id] = win
    return win

def close_page(page_id):
    if page_id in windows:
        win = windows.pop(page_id)
        win.destroy()

# ---------------------------------------------------------------------
# Flask-Routen
# ---------------------------------------------------------------------
@app.route("/<page>")
def page(page):
    if request.args.get("t") != TOKEN:
        abort(404)
    return render_template(f"{page}.html", stream_url=f"/stream?t={TOKEN}")

@app.route("/stream")
def stream():
    if request.args.get("t") != TOKEN:
        abort(404)

    q = Queue()
    with subs_lock:
        subscribers.add(q)

    def gen():
        try:
            yield f"data: {json.dumps({'name':'status','value':'verbunden'})}\n\n"
            while True:
                item = q.get()
                yield f"data: {json.dumps(item, ensure_ascii=False)}\n\n"
        finally:
            with subs_lock:
                subscribers.discard(q)

    return Response(
        gen(),
        mimetype="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )

# ---------------------------------------------------------------------
# Server-Start (wahlweise Flask oder Waitress)
# ---------------------------------------------------------------------
def run_server(server="flask", host="127.0.0.1", port=5000, threads=12):
    if server == "waitress":
        waitress_serve(app, host=host, port=port, threads=threads)

    elif server == "flask":
        app.run(host=host, port=port, debug=False, use_reloader=False)

    else:
        print("[ERROR] Kein gültiger Server ausgewählt! Bitte 'flask' oder 'waitress' angeben.")

def add_worker(func):
    threading.Thread(target=func, daemon=True).start()