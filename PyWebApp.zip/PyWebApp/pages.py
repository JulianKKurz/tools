from ui_bridge import create_page, close_page, html_refresh_variable, add_worker

from ui_bridge import create_page, close_page

class PageApi:
    page_id = None
    title = None

    def __init__(self, **kwargs):
        if not self.page_id or not self.title:
            raise ValueError("page_id and title must be set")

        # Default window settings
        defaults = dict(
            frameless=False,   # remove window frame if True
            fullscreen=False,  # start in fullscreen if True
            easy_drag=False,   # allow dragging frameless windows if True
            on_top=False       # keep window always on top if True
        )

        # Merge defaults with user-provided kwargs (kwargs overrides defaults)
        settings = {**defaults, **kwargs}

        # Create the page with merged settings
        create_page(self.title, self.page_id, js_api=self, **settings)

    def close(self):
        # Close this page/window
        close_page(self.page_id)

    def ui_event(self, event: str, value=None):
        # Handle UI events from the frontend
        print(f"[UI EVENT] {event} = {value}", flush=True)
        handler = getattr(self, f"on_{event}", None)
        if callable(handler):
            return handler(value)
        print(f"[WARN] no handler for {event}", flush=True)

class Index(PageApi):
    page_id = "index"
    title = "SIKAmet"

    def on_mybtn(self, _):
        html_refresh_variable("Button geklickt!", "status", prop="text")
        html_refresh_variable(True, "lock_button")
        Popup(width=400, height=300, resizable=False)

    def on_slider(self, value):
        print(f"Slider = {value}")

    def on_mybtn(self, _):
        print("mybtn gedrückt")
        html_refresh_variable("Button geklickt!", "status", prop="text")
        html_refresh_variable(42, "value", prop="text")
        html_refresh_variable(True, "lock_button", prop="disabled")

    def error(self, text):
        print(text)

class Popup(PageApi):
    page_id = "popup"
    title = "Popup"

    def on_popup_close(self, _):
        print("Popup schließen")
        html_refresh_variable(False, "lock_button")
        self.close()
